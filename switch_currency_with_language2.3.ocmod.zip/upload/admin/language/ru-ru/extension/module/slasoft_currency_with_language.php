<?php
// Heading
$_['heading_title']    = 'SlaSoft :: Зависимости валюты от языка';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: Вы изменили расширение Зависимости валюты от языка!';
$_['text_edit']        = 'Редактирование расширения Зависимости валюты от языка';
$_['text_select_currency'] = 'Выберите валюту для %s';

// Entry

// Error
$_['error_permission'] = 'Warning: Вы не можете изменять настройки расширения!';