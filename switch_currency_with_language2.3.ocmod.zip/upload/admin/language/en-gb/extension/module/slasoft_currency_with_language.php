<?php
// Heading
$_['heading_title']    = 'Currency based on language';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified extension based on currency of language!';
$_['text_edit']        = 'Edit the extension based on the currency of the language';

// Entry

// Error
$_['error_permission'] = 'Warning: You cannot change the extension settings!';